document.addEventListener('DOMContentLoaded', () => {
    const display = document.getElementById('display');
    const buttons = document.querySelectorAll('.btn');
    const clearButton = document.getElementById('clear');
    const equalsButton = document.getElementById('equals');
    let currentInput = '';
    let operator = '';
    let previousInput = '';
    let shouldResetInput = false;

    buttons.forEach(button => {
        button.addEventListener('click', () => {
            const value = button.getAttribute('data-value');
            if (value) {
                handleInput(value);
                speak(value);
            }
        });
    });

    clearButton.addEventListener('click', () => {
        resetCalculator();
        speak('clear');
    });

    equalsButton.addEventListener('click', () => {
        if (currentInput && previousInput && operator) {
            const result = calculate(previousInput, currentInput, operator);
            updateDisplay(result);
            speak(result);
            previousInput = result;
            currentInput = '';
            operator = '';
            shouldResetInput = true;
        }
    });

    function handleInput(value) {
        if (isOperator(value)) {
            if (currentInput && previousInput && operator) {
                previousInput = calculate(previousInput, currentInput, operator);
                updateDisplay(previousInput);
                speak(previousInput);
            } else if (!previousInput) {
                previousInput = currentInput;
            }
            operator = value;
            currentInput = '';
        } else {
            if (shouldResetInput) {
                currentInput = value;
                shouldResetInput = false;
            } else {
                currentInput += value;
            }
            updateDisplay(currentInput);
        }
    }

    function updateDisplay(value) {
        display.innerText = value || '0';
    }

    function calculate(a, b, op) {
        a = parseFloat(a);
        b = parseFloat(b);
        switch (op) {
            case '+': return (a + b).toString();
            case '-': return (a - b).toString();
            case '*': return (a * b).toString();
            case '/': return (a / b).toString();
            default: return b.toString();
        }
    }

    function isOperator(value) {
        return ['+', '-', '*', '/'].includes(value);
    }

    function speak(text) {
        const utterance = new SpeechSynthesisUtterance(text);
        speechSynthesis.speak(utterance);
    }

    function resetCalculator() {
        currentInput = '';
        previousInput = '';
        operator = '';
        shouldResetInput = false;
        updateDisplay('0');
    }
});